function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6CvdjVXUuan":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

